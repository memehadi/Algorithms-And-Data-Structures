#! /usr/bin/env python3

import random
import math
import copy

class Node: #Data structure to hold the value of each node should be hashable
    def __init__(self, i, j, edgeWeight, value = math.inf, neighbours = []):
        self.value = value
        self.i = i
        self.j = j
        self.edgeWeight = edgeWeight
        self.neighbours = neighbours
    
    def __eq__(self,other):
        if other:
            return (self.i,self.j,self.edgeWeight,self.value) == (other.i,other.j,other.edgeWeight,other.value)  
        return False      
    def __ne__(self,other):
        if other:
            return not(self == other)    
        return False
    #Overload index operator for cleaner code
    #0 = i, 1 = j, 2 = edgeWeight, 3 = Value
    def __getitem__(self,index):
        if index == 0:
            return self.i
        if index == 1:
            return self.j
        if index == 2:
            return self.edgeWeight
        if index == 3:
            return self.value


class PuzzleBoard:
    def __init__(self, boardSize, fields = None):
        self.boardSize = boardSize
        if fields == None:
            self.fields = []
            for i in range(boardSize):
                self.fields.append([])
                for j in range(boardSize):
                    self.fields[i].append(random.randint(1,boardSize-1))
        else:
            self.fields = fields
        self.nodes = []
        for i in range(boardSize):
            self.nodes.append([])
            for j in range(boardSize):
                self.nodes[i].append(Node(i,j,self.fields[i][j]))

        self.nodes[0][0].value = 0

        #Match Possible Neigbours
        for i in range(boardSize):
            for j in range(boardSize):
                if i - self.nodes[i][j].edgeWeight >= 0:
                    self.nodes[i][j].neighbours.append(self.nodes[i-self.nodes[i][j].edgeWeight][self.nodes[i][j].j])
                else:
                    self.nodes[i][j].neighbours.append(None)
                if j + self.nodes[i][j].edgeWeight < boardSize:
                    self.nodes[i][j].neighbours.append(self.nodes[self.nodes[i][j].i][j+self.nodes[i][j].edgeWeight])
                else:
                    self.nodes[i][j].neighbours.append(None)
                if i + self.nodes[i][j].edgeWeight < boardSize:
                    self.nodes[i][j].neighbours.append(self.nodes[i+self.nodes[i][j].edgeWeight][self.nodes[i][j].j])
                else:
                    self.nodes[i][j].neighbours.append(None)
                if j - self.nodes[i][j].edgeWeight >= 0:
                    self.nodes[i][j].neighbours.append(self.nodes[self.nodes[i][j].i][j-self.nodes[i][j].edgeWeight])
                else:
                    self.nodes[i][j].neighbours.append(None)
                

    def checkValid(self,direction,i_pos=0,j_pos=0):
        if direction == 0:
            if i_pos - self.nodes[i_pos][j_pos].edgeWeight >= 0:
                return True
            else:
                return False
        if direction == 1:
            if j_pos + self.nodes[i_pos][j_pos].edgeWeight < self.boardSize:
                return True
            else:
                return False
        if direction == 2:
            if i_pos + self.nodes[i_pos][j_pos].edgeWeight < self.boardSize:
                return True
            else:
                return False
        if direction == 3:
            if j_pos - self.nodes[i_pos][j_pos].edgeWeight >= 0:
                return True
            else:
                return False
        else:
            raise "Error in value"

    def makeMove(self,direction,i_pos = 0, j_pos = 0):
        if not self.checkValid(direction,i_pos,j_pos):
            return False
        if direction == 0:
            self.nodes[i_pos][j_pos].neighbours[0].value = 1 + self.nodes[i_pos][j_pos].value
            self.nodes[i_pos-self.nodes[i_pos][j_pos].edgeWeight][j_pos].value = 1 + self.nodes[i_pos][j_pos].value
        if direction == 1:
            self.nodes[i_pos][j_pos].neighbours[1].value = 1 + self.nodes[i_pos][j_pos].value
            self.nodes[i_pos][j_pos+self.nodes[i_pos][j_pos].edgeWeight].value = 1 + self.nodes[i_pos][j_pos].value
        if direction == 2:
            self.nodes[i_pos][j_pos].neighbours[2].value = 1 + self.nodes[i_pos][j_pos].value
            self.nodes[i_pos+self.nodes[i_pos][j_pos].edgeWeight][j_pos].value = 1 + self.nodes[i_pos][j_pos].value
        if direction == 3:
            self.nodes[i_pos][j_pos].neighbours[3].value = 1 + self.nodes[i_pos][j_pos].value
            self.nodes[i_pos][j_pos-self.nodes[i_pos][j_pos].edgeWeight].value = 1 + self.nodes[i_pos][j_pos].value
        else:
            raise "Invalid Entry"

    def __str__(self):
        L = ""
        for i in range(self.boardSize):
            for j in range(self.boardSize):
                L += str(self.fields[i][j]) + "\t"
            L += "\n\n"

        return L

    def getResult(self):
        if self.nodes[self.boardSize-1][self.boardSize-1] != math.inf:
            return True
        else:
            return False

    def solve(self):
        S = []
        Q = copy.deepcopy(self.nodes)
        while len(Q) != 0:
            y = [v.index(min([min(u.value) for u in self.nodes])) for v in self.nodes]
            x = [self.nodes.index(v) for v in self.nodes if y in v]
            S.append([x,y])
            for n in self.nodes[x][y].neighbours:
                if n.value > self.nodes[x][y].value + self.nodes[x][y].edgeWeight:
                    self.makeMove(self.nodes[x][y].neighbours.index(n),x,y)
        self.





    