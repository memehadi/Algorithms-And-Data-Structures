#! /usr/bin/env python3
import random
import math
import copy
from collections import namedtuple




class Node: #Data structure to hold the value of each node should be hashable
    def __init__(self, i, j, edgeWeight, value = math.inf):
        self.value = value
        self.i = i
        self.j = j
        self.edgeWeight = edgeWeight
    def __hash__(self):
        return hash((self.i,self.j,self.edgeWeight,self.value))
    def __eq__(self,other):
        if other:
            return (self.i,self.j,self.edgeWeight,self.value) == (other.i,other.j,other.edgeWeight,other.value)  
        return False      
    def __ne__(self,other):
        if other:
            return not(self == other)    
        return False
    #Overload index operator for cleaner code
    #0 = i, 1 = j, 2 = edgeWeight, 3 = Value
    def __getitem__(self,index):
        if index == 0:
            return self.i
        if index == 1:
            return self.j
        if index == 2:
            return self.edgeWeight
        if index == 3:
            return self.value


class PuzzleBoard:
    def __init__(self, boardSize, fields = None):
        self.boardSize = boardSize
        if fields == None:
            self.fields = []
            for i in range(boardSize):
                self.fields.append([])
                for j in range(boardSize):
                    self.fields[i].append(random.randint(1,boardSize-1))
        else:
            self.fields = fields
        #Setup board according to rule 
        #Board data structure set as library
        #Each key represents a node and the values represent neighbour nodes
        self.board = {}
        for i in range(len(self.fields)):
            for j in range(len(self.fields)):
                #set the value of the top left piece of the board to 0 
                #First step of the shortest path algorithm
                if i == 0 and j == 0:
                    self.board[Node(i,j,self.fields[i][j],0)] = []
                    if i - self.fields[i][j] >= 0:#get up neighbour
                        self.board[Node(i,j,self.fields[i][j],0)] += [Node(i - self.fields[i][j],j,self.fields[i-self.fields[i][j]][j],math.inf)]
                        
                    else:#if it doesnt exist append 0 so that there wouldn't be an index mismatch
                        self.board[Node(i,j,self.fields[i][j],0)] += [None]
                    if j + self.fields[i][j] < self.boardSize:#get right neighbour
                        self.board[Node(i,j,self.fields[i][j],0)] += [Node(i, j + self.fields[i][j],self.fields[i][j+self.fields[i][j]],math.inf)]
                        
                    else:
                        self.board[Node(i,j,self.fields[i][j],0)] += [None]
                    if i + self.fields[i][j] < self.boardSize:#get down neighbour
                        self.board[Node(i,j,self.fields[i][j],0)] += [Node(i + self.fields[i][j],j,self.fields[i+self.fields[i][j]][j],math.inf)]
                    else:
                        self.board[Node(i,j,self.fields[i][j],0)] += [None]
                    if j - self.fields[i][j] >= 0:#get left neighbour
                        self.board[Node(i,j,self.fields[i][j],0)] += [Node(i, j - self.fields[i][j],self.fields[i][j-self.fields[i][j]],math.inf)]
                    else:
                        self.board[Node(i,j,self.fields[i][j],0)] += [None]
                else:
                    self.board[Node(i,j,self.fields[i][j],math.inf)] = []
                    if i - self.fields[i][j] >= 0:#get up neighbour
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [Node(i - self.fields[i][j],j,self.fields[i-self.fields[i][j]][j],math.inf)]
                        print("here",self.board[Node(i,j,self.fields[i][j],math.inf)][0].edgeWeight,self.fields[i][j])
                    else:#if it doesnt exist append 0 so that there wouldn't be an index mismatch
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [None]
                    if j + self.fields[i][j] < self.boardSize:#get right neighbour
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [Node(i, j + self.fields[i][j],self.fields[i][j+self.fields[i][j]],math.inf)]
                    else:
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [None]
                    if i + self.fields[i][j] < self.boardSize:#get down member
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [Node(i + self.fields[i][j],j,self.fields[i+self.fields[i][j]][j],math.inf)]
                    else:
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [None]
                    if j - self.fields[i][j] >= 0:#get left neighbour
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [Node(i, j - self.fields[i][j],self.fields[i][j-self.fields[i][j]],math.inf)]
                    else:
                        self.board[Node(i,j,self.fields[i][j],math.inf)] += [None]
                
    #check if the current can move in the specified direction
    #curr = Node(i,j,edgeWeight,value)
    #has overloaded [] operator
    #checks moves by considering a list as a matrix where moving around would need some % and * operations
    def checkValid(self, direction):
        if direction == 0:
            if list(self.board.keys()).index(self.curr) - self.curr[2]*self.boardSize < 0: #up_move
                return False
            else:
                return True
        elif direction == 2: #down_move
            if list(self.board.keys()).index(self.curr) + self.curr[2]*self.boardSize >= self.boardSize*self.boardSize:
                return False
            else:
                return True
        elif direction == 1: #right
            if (list(self.board.keys()).index(self.curr))%(self.boardSize-1) + self.curr[2] >= self.boardSize:
                return False
            else:
                return True
        elif direction == 3: #left
            if (list(self.board.keys()).index(self.curr))%(self.boardSize-1) - self.curr[2] < 0:
                return False
            else:
                return True
        else:
            raise "Invalid entry"
    
    #change the current position and update value by adding one to the value of the previous one
    #changes like going up and down in matrix. If going up then decrease by i*boardsize
    def makeMove(self, direction):
        if not self.checkValid(direction):
            return False
 
        v = self.curr[3]
        if direction == 0: #up
            self.curr = list(self.board.keys())[list(self.board.keys()).index(self.curr) - self.curr[2]*self.boardSize - 1]
        elif direction == 2: #down
            self.curr = list(self.board.keys())[list(self.board.keys()).index(self.curr) + self.curr[2]*self.boardSize - 1]
        elif direction == 3: #left
            self.curr = list(self.board.keys())[list(self.board.keys()).index(self.curr) - self.curr[2]]
        elif direction == 1: #right
            self.curr = list(self.board.keys())[list(self.board.keys()).index(self.curr) + self.curr[2]]
        else:    
            raise "Invalid input"
        temp,x = copy.deepcopy(self.curr),self.board[self.curr]

        temp1 = Node(self.curr.i,self.curr.j,self.curr.edgeWeight,v+1)
        del self.board[self.curr]
        self.curr = copy.deepcopy(temp1)
        self.board[self.curr] = x
        return True

    #Check if the last node has been reached
    def getResult(self):
        if self.curr[0] == self.boardSize-1 and self.curr[1] == self.boardSize-1:
            return True
        return False

    def __str__(self):
        L = ""
        for i in range(self.boardSize):
            for j in range(self.boardSize):
                L += str(self.fields[i][j]) + "\t"
            L += "\n\n"

        return L

    def solve(self): #shortest distance
        S = []
        Q = copy.copy(self.board)
        while len(Q) != 0:
            temp,adju = (list(Q.items())[([x[3] for x in Q.keys()]).index(min([x[3] for x in Q.keys()]))])
            Q.pop(temp)
            S.append(temp)
            for v in adju:
                if v:
                    if v[3] > temp[3] + 1:
                        self.curr = copy.deepcopy(temp)
                        self.makeMove(adju.index(v))
                        Q = copy.deepcopy(self.board)
                        Q.pop(temp)
                        if self.getResult():
                            return len(S) 
        return -1                   

A = PuzzleBoard(3)
print(A)

print(A.solve())

print("Printing Board")

for key in A.board.keys():
    print(key[3],' : ',end = "")
    for val in A.board[key]:
            print(val, end = " ")
    print("\n")